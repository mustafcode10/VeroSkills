export function ToggleOn({ children }) {
  return children;
}
