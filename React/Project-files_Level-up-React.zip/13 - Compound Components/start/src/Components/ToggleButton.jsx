export const ToggleButton = () => {
  return <button>Sign up</button>;
};
