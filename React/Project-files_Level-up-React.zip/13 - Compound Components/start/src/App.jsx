import "./App.css";

function App() {
  return <h2>Toggle</h2>;
}

export default App;
