import RecipeRating from "./RecipeRating";

export default function Recipe() {
  return (
    <div className="card">
      <div>
        <img />
      </div>
      <h2>Recipe</h2>
      <RecipeRating />
    </div>
  );
}
