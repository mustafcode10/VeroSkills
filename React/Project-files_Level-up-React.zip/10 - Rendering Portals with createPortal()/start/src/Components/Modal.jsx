export function Modal(props) {
  return <h2>A Modal</h2>;
}
