import "./App.css";

function App() {
  return (
    <div>
      <h1>My React App</h1>
      <button>Toggle Modal</button>
    </div>
  );
}

export default App;
