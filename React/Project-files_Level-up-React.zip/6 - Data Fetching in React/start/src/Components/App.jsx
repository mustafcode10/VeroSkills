import Recipe from "./Recipe";

export default function App() {
  return (
    <>
      <h1>My Favorite Recipes</h1>
      <div className="categories">
        <label htmlFor="categorySelect">Select Category: </label>
        <select id="categorySelect"></select>
      </div>
      <div className="container"></div>
    </>
  );
}
