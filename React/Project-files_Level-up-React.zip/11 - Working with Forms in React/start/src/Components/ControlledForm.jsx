export function ControlledForm() {
  return (
    <form>
      <label>Name:</label>
      <input type="text" />
    </form>
  );
}
