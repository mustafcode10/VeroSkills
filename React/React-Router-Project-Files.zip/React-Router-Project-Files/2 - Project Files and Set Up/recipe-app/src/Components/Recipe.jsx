export default function Recipe() {
  return (
    <div className="container recipe">
      <h2>Recipe Name</h2>
      <div className="recipe-container">
        <img alt="" />
        <div className="recipe-instructions">
          <p>Instructions...</p>
          <a href="#" target="_blank">
            Watch YouTube video!
          </a>
        </div>
      </div>
    </div>
  );
}
