import RecipeRating from "./RecipeRating";

export function RecipeCard({ data }) {
  return (
    <div className="card">
      <div>
        <img src={data.strMealThumb} alt={data.strMeal} title={data.strMeal} />
      </div>
      <h2>{data.strMeal}</h2>
      <RecipeRating />
    </div>
  );
}
