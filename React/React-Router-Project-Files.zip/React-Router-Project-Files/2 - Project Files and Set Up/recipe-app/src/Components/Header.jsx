import { useState, useEffect } from "react";

export default function Header() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch("https://www.themealdb.com/api/json/v1/1/categories.php")
      .then(response => response.json())
      .then(data => setCategories(data.categories))
      .catch(error => console.error("Error:", error));
  }, []);

  return (
    <div>
      <h1>My Favorite Recipes</h1>
      <nav>
        {categories.map(category => (
          <a href="#" key={category.idCategory}>
            {category.strCategory}
          </a>
        ))}
      </nav>
    </div>
  );
}
