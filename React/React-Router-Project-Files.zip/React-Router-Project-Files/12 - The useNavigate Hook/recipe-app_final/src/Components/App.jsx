import Header from "./Header";
import Home from "./Home";
import Recipes from "./Recipes";
import NotFound from "./NotFound";
import { Routes, Route } from "react-router-dom";

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path="/"
          element={<Home title="Choose your favorite recipes" />}
        />
        <Route path=":category" element={<Recipes />} />
        <Route path="/404" element={<NotFound />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
