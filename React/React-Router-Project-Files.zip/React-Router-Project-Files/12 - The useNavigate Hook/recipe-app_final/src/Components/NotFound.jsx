export default function NotFound() {
  return <h2 className="not-found">Page Not Found!</h2>;
}
