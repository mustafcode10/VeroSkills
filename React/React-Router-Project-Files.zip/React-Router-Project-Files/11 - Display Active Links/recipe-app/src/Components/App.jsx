import Header from "./Header";
import Home from "./Home";
import Recipes from "./Recipes";
import { Routes, Route } from "react-router-dom";

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path="/"
          element={<Home title="Choose your favorite recipes" />}
        />
        <Route path=":category" element={<Recipes />} />
        <Route
          path="*"
          element={<h2 className="not-found">Page Not Found!</h2>}
        />
      </Routes>
    </>
  );
}
