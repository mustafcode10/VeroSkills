import { Outlet, Link } from "react-router-dom";
export default function Recipes() {
  return (
    <div className="container">
      <>
        <h2>Recipes</h2>
        <nav>
          <Link to="/recipes/desserts">Desserts</Link> |
          <Link to="/recipes/main-dishes">Main Dishes</Link> |
          <Link to="/recipes/appetizers">Appetizers</Link>
        </nav>
        <Outlet />
      </>
    </div>
  );
}
