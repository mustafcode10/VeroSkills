const MainDishes = () => {
  return (
    <>
      <h3>Main Dishes</h3>
      <p>Find recipes for stunning main dishes.</p>
    </>
  );
};

export default MainDishes;
