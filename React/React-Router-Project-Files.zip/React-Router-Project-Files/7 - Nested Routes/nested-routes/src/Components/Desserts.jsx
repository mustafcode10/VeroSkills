const Desserts = () => {
  return (
    <>
      <h3>Desserts</h3>
      <p>Explore delicious dessert recipes!</p>
    </>
  );
};

export default Desserts;
