import Header from "./Header";
import Home from "./Home";
import Recipes from "./Recipes";
import Desserts from "./Desserts";
import MainDishes from "./MainDishes";
import Appetizers from "./Appetizers";
import { Routes, Route } from "react-router-dom";

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path="/"
          element={<Home title="Choose your favorite recipes" />}
        />
        <Route path="/recipes" element={<Recipes />} />
      </Routes>
    </>
  );
}
