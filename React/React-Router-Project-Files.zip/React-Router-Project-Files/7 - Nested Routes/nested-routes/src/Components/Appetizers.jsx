const Appetizers = () => {
  return (
    <>
      <h3>Appetizers</h3>
      <p>Start your meal with these appetizers.</p>
    </>
  );
};

export default Appetizers;
