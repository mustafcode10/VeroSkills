import { Link } from "react-router-dom";

export default function Header() {
  return (
    <div>
      <Link to="/" className="title">
        <h1>My Favorite Recipes</h1>
      </Link>
    </div>
  );
}
