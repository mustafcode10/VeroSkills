import OpenAI from "openai";

export default new OpenAI({
  apiKey: "YOUR_KEY",
  dangerouslyAllowBrowser: true,
});
