import OpenAI from "openai";

export default new OpenAI({
  apiKey: "YOUR API KEY",
  dangerouslyAllowBrowser: true,
});
